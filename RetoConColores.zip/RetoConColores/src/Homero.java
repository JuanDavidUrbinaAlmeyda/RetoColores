public class Homero {
    double kg;
    String trabajo,ropa ;
    int edad;

    public double getKg() {
        return kg;
    }

    public void setKg(double kg) {
        this.kg = kg;
    }

    public String getTrabajo() {
        return trabajo;
    }

    public void setTrabajo(String trabajo) {
        this.trabajo = trabajo;
    }

    public String getRopa() {
        return ropa;
    }

    public void setRopa(String ropa) {
        this.ropa = ropa;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void trabajar(String trabajo){
        System.out.println("Homero va a trabajar en "+getTrabajo());
    }
    public String comer_algo(String c){
        return c;
    }
    public boolean vertv(boolean t){
        return t;
    }
}
