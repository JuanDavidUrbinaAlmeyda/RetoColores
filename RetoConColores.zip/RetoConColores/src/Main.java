public class Main{
    public static void main(String[]args){
        //Creación de Objetos
        Perro p1=new Perro();
        WinniPoh w1= new WinniPoh();
        Robot r1= new Robot();
        Basquetbolista b1= new Basquetbolista();
        Homero h1=new Homero();

        //Atributos
        p1.setNombre("Franchesco");
        System.out.println("El perro se llama "+p1.nombre);
        w1.setHabitat("Bosque");
        w1.setEdad(2);
        w1.describir();
        r1.setName("R8-XC");
        r1.setColor("Azul");
        r1.setAltura(12.5);
        System.out.println("El robot llamado "+r1.getName()+" de color "+r1.getColor()+" tiene una altura de "+r1.getAltura()+" centimetros");
        b1.setDorsal(10);
        b1.setTriples(7);
        b1.estadistica();
        h1.setTrabajo("Planta Nuclear");
        h1.trabajar(h1.trabajo);
    }
}