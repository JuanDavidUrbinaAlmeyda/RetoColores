public class Perro {
    //Atributos
    int peso;
    String nombre, raza,color;

    //Getters y Setters
    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    //Métodos
    public static String ladrar(String l){

        return l;
    }
    public static int alimentar(int cantidad){
        return cantidad;
    }
    public static Boolean pasear(boolean p){
        return p;
    }

}
