import java.io.PrintStream;

public class WinniPoh {
    private int edad;
    private String comidaFavorita,color, habitat;

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getComidaFavorita() {
        return comidaFavorita;
    }

    public void setComidaFavorita(String comidaFavorita) {
        this.comidaFavorita = comidaFavorita;
    }


    public int getEdad() {
        return this.edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

   public void comer_favorita(){
        System.out.println("Estás comiendo "+getComidaFavorita());

   }
   public void describir(){
        System.out.println("Hola!, soy Winnie Pooh, tengo "+getEdad()+" años y vivo en "+getHabitat());


   }
    public void dormir(){
        System.out.println("A dormir");
    }

}