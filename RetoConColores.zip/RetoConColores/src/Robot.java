
import static java.lang.Boolean.TRUE;


public class Robot {
    private String color,nombre;
    private double altura;
    private boolean encendido;
    private String pierna,piernas;
    private String brazo,brazos;
    private int cantidaddePiernas,cantidaddeBrazos,cantidadDeLlantas;
    
    public String getName(){
       return nombre;
    }  
    public void setName(String name){
       this.nombre=name;
   }
   public String getColor(){
       return color;
    }  
    public void setColor(String color){
       this.color=color;
   }
   public double getAltura(){
       return altura;
    }  
    public void setAltura(double altura){
       this.altura=altura;
   }
   public int getCantidadDeLlantas(){
       return cantidadDeLlantas;
    }  
    public void setCantidadDeLlantas(int cantidadDeLlantas){
       this.cantidadDeLlantas=cantidadDeLlantas;
   }
    
    public String moverPiernas(){
        String piernas = "Levanta la pierna de la izquierda, impulsela hacia adelante, apoyela en el piso y luego repitalo con cada una de las piernas del robot";
        
        if (cantidaddePiernas==1){
        String pierna = "Se mueve con impulso de las llantas";        
            return pierna;}
        if (cantidaddePiernas<1){
        String pierna = "No se pueden mover las piernas porque no tiene";        
            return pierna;}
        else {return piernas;
        }
    }
    public String moverBrazos(){
        String brazos = "Levanta el brazo de la izquierda, devuelva el brazo al lugar de origen, y luego repitalo con cada uno de los brazos del robot";
        
        if (cantidaddeBrazos==1){
        String brazo  = "Levante el único brazo y luego devuelvalo al lugar de origen";        
            return brazo;}
        if (cantidaddeBrazos<1){
        String brazo = "No se pueden mover los brazos porque no tiene";        
            return brazo;}
        else {return brazos;
        }
    }
    
    String circ="Se prenden todos los sistemas del robot ";
    public String encender(){
        if (encendido==TRUE ) {
            String circ="Se prenden todos los sistemas del robot ";
        }
        else {String circ="Está descargado o dañado reviselo ";}
        return circ;
        }
 }

